const { default: mongoose } = require("mongoose");
const SignToken = require("../jwt");
const UserModel = require("./User.Schema");
const jwt = require('jsonwebtoken');
const PointModel = require("../point/Point.Schema");
const TaskCompletedController = require("../task_completed/TaskComplete.Controller");

const CreateUser = async (req, res) => {
  try {
    // Step 1: Create user
    const UserOBJ = {
      ...req.body,
      CompleteTask: 0,
      isBlocked: false,
      isDeleted: false,
    };

    const createdUser = await UserModel.create(UserOBJ);
    console.log("User created:", createdUser);
    
    // Step 2: Initialize points for the new user to 100
    const PointOBJ = {
      userId: createdUser?._id,
      points: 100,  // Set initial points to 100
    };
    
    const createdPoint = await PointModel.create([PointOBJ]);
    console.log("Points initialized:", createdPoint);

    res.status(200).send({
      data: createdUser,
      statusCode: 200,
      msg: 'User is created and points are initialized!',
    });
  } catch (error) {
    console.error("Error creating user and initializing points:", error);
    res.status(200).send({
      msg: 'Error creating user',
      error: process.env.MODE === 'DEV' ? error.message : undefined,
    });
  }
};

const UpdateUser = async (req, res) => {
  const body = req.body;

  try {
    const updateResult = await UserModel.updateOne({ userId: body?.userId }, { ...body });

    if (updateResult.nModified === 0) {
      return res.status(404).json({ message: "User not found or no changes made" });
    }

    res.status(200).json({ message: "User updated successfully", updateResult });
  } catch (error) {
    console.error("Error updating user:", error);
    res.status(500).json({ message: "Internal server error", error: error.message });
  }
};

const FindUser = async (req, res) => {
  const Query = req.query.userId;
  try {
    const FindUser = await UserModel.findOne({ userId: Query });
    if (!FindUser) {
      return res.status(200).json({ message: "User not found" });
    }
    res.status(200).json(FindUser);
  } catch (error) {
    console.error("Error finding user:", error);
    res.status(200).json({ message: "Internal server error", error: error.message });
  }
};

module.exports = {
  CreateUser,
  FindUser,
  UpdateUser,
};
