const { default: mongoose } = require("mongoose");
const { Schema, model } = require("mongoose");

const UserSchema = new Schema({
    userId: {
        type: Number,  // Change to ObjectId for MongoDB reference  mongoose.Schema.Types.ObjectId
        required: true,
        unique: true 
    },
    username: {
        type: String,
        required: true,
    },
    fullName: {
        type: String,
        required: true,
    },
    isBlocked: {
        type: Boolean,
        required: true,
        default: false
    },
    isDeleted: {
        type: Boolean,
        required: true,
        default: false
    },
    profilePicture: {
        type: String,
        default: null
    },
    completedTask: Number,

    role: {
        type: String,
        default: "user"
    },
}, { timestamps: true });

const UserModel = model("user", UserSchema);

module.exports = UserModel;
