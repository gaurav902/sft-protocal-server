const express = require('express');
const { CreateUser, FindUser, UpdateUser } = require('./user/User.Controller');
const { LeaderboardByPoints } = require('./point/Point.Controller');
const { CreateNewTask, TaskList } = require('./task/Task.Controller');
const { CompleteTask } = require('./task_completed/TaskComplete.Controller');
const MainRoutes = express.Router();




MainRoutes.post('/create-account', CreateUser);
MainRoutes.get('/find-account', FindUser);
MainRoutes.put('/update-account', UpdateUser);
MainRoutes.get('/leaderboard', LeaderboardByPoints);
MainRoutes.post('/create-task', CreateNewTask);
MainRoutes.post('/complete-task', CompleteTask);
MainRoutes.get('/task-list', TaskList);

module.exports = MainRoutes;