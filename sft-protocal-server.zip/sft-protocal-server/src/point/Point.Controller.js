const PointModel = require("./Point.Schema");

const LeaderboardByPoints = async(req, res) => {
    try {
        const Leader = await PointModel
            .find({})
            .sort({ points: -1 })  // Make sure you are sorting by points
            .limit(50)
            .populate('userId', '-isBlocked -isDeleted -createdAt -updatedAt')  // Properly populate and exclude unwanted fields
            .exec();

        res.send({
            msg: 'New Leaderboard list!',
            statusCode: 200,
            data: Leader,
        });
    } catch (error) {
        console.error(error);
        res.status(500).send({ msg: 'Internal server error' });
    }
};

module.exports = { LeaderboardByPoints };
