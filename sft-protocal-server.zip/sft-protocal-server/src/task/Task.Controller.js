const TaskCompletedModel = require("../task_completed/TaskComplete.Schema");
const TaskModel = require("./Task.Schema");
const mongoose = require("mongoose");

const CreateNewTask = async (req, res) => {
  try {
    const body = req.body;
    const TaskObj = {
      ...body,
      participateCount: 0,
      isPause: false,
      isDelete: false,
    };

    const result = await TaskModel.create(TaskObj);

    return res.status(200).json({
      msg: "New task inserted!",
      statusCode: 200,
      data: result,
    });
  } catch (error) {
    console.error("Error creating task:", error);
    return res.status(500).json({
      msg: error?.message || "Internal server error",
      statusCode: 500,
    });
  }
};

const TaskList = async (req, res) => {
  const userId = req.body.userId;

  try {
    // Fetch all tasks and completed tasks by the user
    const allTasks = await TaskModel.find({}).sort({ updatedAt: -1 });
    const completedTasks = await TaskCompletedModel.find({ userId });

    // Create a set of task IDs that the user has completed for fast lookup
    const completedTaskIds = new Set(completedTasks.map(task => task.taskId.toString()));

    // Map through each task and set `isComplete` based on whether the task ID is in completedTaskIds
    const tasksWithCompletionStatus = allTasks.map(task => ({
      ...task._doc,
      isComplete: completedTaskIds.has(task._id.toString()) ? true : false // Explicitly setting false if not completed
    }));

    return res.status(200).send({
      msg: "Task list retrieved successfully!",
      statusCode: 200,
      data: tasksWithCompletionStatus,
    });
  } catch (error) {
    console.error("Failed to retrieve task list:", error);
    return res.status(500).send({
      msg: "Failed to retrieve task list.",
      statusCode: 500,
      data: [],
    });
  }
};

module.exports = {
  CreateNewTask,
  TaskList,
};
