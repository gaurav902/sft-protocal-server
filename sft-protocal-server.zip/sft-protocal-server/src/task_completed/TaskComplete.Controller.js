const mongoose = require("mongoose");
const UserModel = require("../user/User.Schema");
const TaskModel = require("../task/Task.Schema");
const TaskCompletedModel = require("./TaskComplete.Schema");

const CompleteTask = async (req, res) => {
  const { userId, taskId } = req.body;

  try {
    // Step 1: Retrieve user document by userId field
    const readUser = await UserModel.findOne({ userId: Number(userId) });
    if (!readUser) {
      return res.send({
        msg: "User not found!",
        statusCode: 400,
        data: [],
      });
    }

    // Step 2: Retrieve task document by _id
    const readTask = await TaskModel.findById(taskId);
    if (!readTask) {
      return res.send({
        msg: "Task not found!",
        statusCode: 400,
        data: [],
      });
    }

    // Step 3: Check if the task is already completed by the user
    const findUnique = await TaskCompletedModel.findOne({
      userId: readUser._id, // Use the _id from the UserModel result
      taskId,
    });

    if (findUnique) {
      return res.send({
        msg: "The task is already completed by the user!",
        statusCode: 200,
        data: [],
      });
    }

    // Step 4: Update user's completed task count
    const updatedUser = await UserModel.findByIdAndUpdate(
      readUser._id,
      { completedTask: (readUser.completedTask || 0) + 1 },
      { new: true }
    );

    // Step 5: Create the task completion record
    const completedTask = await TaskCompletedModel.create({
      userId: readUser._id, // Use readUser's _id
      taskId,
    });

    return res.send({
      msg: "Task Completed!",
      statusCode: 200,
      data: { user: updatedUser, task: completedTask },
    });
  } catch (error) {
    console.error("Error completing task:", error);
    return res.send({
      msg: "Error completing task!",
      statusCode: 500,
      data: [],
      error: error.message,
    });
  }
};

module.exports = {
  CompleteTask,
};
