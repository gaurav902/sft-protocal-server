const jwt = require('jsonwebtoken');

const SignToken =  (payload) => {

  return token;
};

module.exports = {
  SignToken
};
