# Database Schema and API Endpoints

## Database Schema

### **User Account**

UserAccount: {
  _id: ObjectId,
  userId: Number,
  username: String,
  fullName: String,
  isBlocked: Boolean,
  isDeleted: Boolean,
  profilePicture: String,
  role: String, // e.g., 'user', 'admin'
  createdAt: Date,
  updatedAt: Date
}

                    **Social Media**
SocialMedia: {
  _id: ObjectId,
  userId: ObjectId, // Reference to UserAccount._id
  twitter: String,
  discord: String,
  cmc: String, // CoinMarketCap profile link
  linkedin: String,
  createdAt: Date,
  updatedAt: Date
}
      **Point System**

PointSystem: {
  _id: ObjectId,
  userId: ObjectId, // Reference to UserAccount._id
  points: Number,
  createdAt: Date,
  updatedAt: Date
}
**Task Info**

Task: {
  _id: ObjectId,
  title: String,
  points: Number,
  category: String,
  startDate: Timestamp, // Previously 'startedAt'
  endDate: Timestamp, // Previously 'endedAt'
  createdAt: Date,
  updatedAt: Date
}
**Task Completion**
TaskCompletion: {
  _id: ObjectId,
  userId: ObjectId, // Reference to UserAccount._id
  taskId: ObjectId, // Reference to Task._id
  createdAt: Date,
  updatedAt: Date
}
**API Endpoints**
User Account APIs
Create Account: POST /api/v1/create-account (Public)
Find Account: GET /api/v1/find-account?key=ObjectId (Authenticated, populates Social)
Update Account: PATCH /api/v1/update-account (Authenticated)
Get All Accounts: GET /api/v1/all-accounts (Admin only)
Delete Account: DELETE /api/v1/delete-account (Admin only)
**Social Media APIs**
Add Social Media: POST /api/v1/add-social (Public)
Update Social Media: PATCH /api/v1/update-social (Authenticated)
Point System APIs
Get User Points: GET /api/v1/get-user-points?userId=ObjectId (Authenticated)
Update User Points: PATCH /api/v1/update-user-points (Admin only)
**Task APIs**
Create Task: POST /api/v1/create-task (Admin only)
Get All Tasks: GET /api/v1/all-tasks (Public)
**Task Completion APIs**
Get Completed Tasks: GET /api/v1/completed-tasks?userId=ObjectId (Authenticated)
Delete Completed Task: DELETE /api/v1/delete-completed-task (Admin only)
Complete Task: POST /api/v1/complete-task (Authenticated)

# sft-protocol-express

Category
1. Telegram
2. Twitter
3. CMC
4. Instagram
5. Youtube
6. Like
7. Comment